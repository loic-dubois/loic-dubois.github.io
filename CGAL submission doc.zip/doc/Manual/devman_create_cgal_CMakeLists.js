var devman_create_cgal_CMakeLists =
[
    [ "How to use CGAL with CMake", "devman_create_and_use_a_cmakelist.html", "devman_create_and_use_a_cmakelist" ]
];