var searchData=
[
  ['xyz_0',['Input/Output (XYZ)',['../../Point_set_3/group__PkgPointSet3IOXYZ.html',1,'']]],
  ['xyz_20formats_1',['I/O (XYZ Formats)',['../../Point_set_processing_3/group__PkgPointSetProcessing3IOXyz.html',1,'']]]
];
