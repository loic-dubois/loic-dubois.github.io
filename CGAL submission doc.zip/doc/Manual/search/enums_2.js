var searchData=
[
  ['channel_0',['Channel',['../../Classification/classCGAL_1_1Classification_1_1Feature_1_1Color__channel.html#a210cdae0dedea79ae89862b80bf94610',1,'CGAL::Classification::Feature::Color_channel']]],
  ['circle_5ftype_1',['Circle_type',['../../Circular_kernel_3/group__PkgCircularKernel3GeometricClasses.html#ga60d9863f63464a769af1e95c50d3f89a',1,'CGAL::Circle_type'],['../../Circular_kernel_3/group__PkgCircularKernel3GeometricClasses.html#ga60d9863f63464a769af1e95c50d3f89a',1,'CGAL::Circle_type']]],
  ['classification_5ftype_2',['Classification_type',['../../Alpha_shapes_2/classCGAL_1_1Alpha__shape__2.html#a910fdb5781b25ae73507d54bb73a63bf',1,'CGAL::Alpha_shape_2::Classification_type'],['../../Alpha_shapes_3/classCGAL_1_1Alpha__shape__3.html#ae887e9ecdaca28790f6ccdd73b84e40c',1,'CGAL::Alpha_shape_3::Classification_type'],['../../Alpha_shapes_3/classCGAL_1_1Fixed__alpha__shape__3.html#a3c4c20b8aa43fbd4667a464f3487516a',1,'CGAL::Fixed_alpha_shape_3::Classification_type']]],
  ['coherence_5ftype_3',['Coherence_type',['../../Point_set_processing_3/classCGAL_1_1Point__set__with__structure.html#aaada4e3848c92698219ee8899b996aaa',1,'CGAL::Point_set_with_structure']]],
  ['comparison_5fresult_4',['Comparison_result',['../../Kernel_23/group__kernel__enums.html#ga84351c7e66be00efccd4ab1a61070469',1,'CGAL']]],
  ['computation_5fpolicy_5f2_5',['Computation_policy_2',['../../Barycentric_coordinates_2/namespaceCGAL_1_1Barycentric__coordinates.html#a478bbcec416216b2274ee4b4e97b0e6c',1,'CGAL::Barycentric_coordinates']]],
  ['cone_5ftype_6',['Cone_type',['../../Surface_mesh_parameterization/group__PkgSurfaceMeshParameterizationEnums.html#gaae0686c0467daddc7328bcba2e1b5a5b',1,'CGAL::Surface_mesh_parameterization']]],
  ['cones_5fselected_7',['Cones_selected',['../../Cone_spanners_2/group__PkgConeSpanners2Ref.html#ga4ecf90e8006c4dee00a21e67bd716462',1,'CGAL']]],
  ['content_8',['Content',['../../Nef_2/classCGAL_1_1Nef__polyhedron__2.html#ab5f1c19c50d23c0a759c2d2b1bb60bd0',1,'CGAL::Nef_polyhedron_2::Content'],['../../Nef_S2/classCGAL_1_1Nef__polyhedron__S2.html#a3ce8658c7c7445e8f074d2c03c945823',1,'CGAL::Nef_polyhedron_S2::Content'],['../../Nef_3/classCGAL_1_1Nef__polyhedron__3.html#a29ea7a3eb633b6b5a8b46b3a76c4126f',1,'CGAL::Nef_polyhedron_3::Content']]]
];
