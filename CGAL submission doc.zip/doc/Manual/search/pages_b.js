var searchData=
[
  ['kernels_0',['Geometry Kernels',['../devman_kernels.html',1,'dev_manual']]]
];
