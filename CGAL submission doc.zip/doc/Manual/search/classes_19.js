var searchData=
[
  ['zcriticalpoints_0',['ZCriticalPoints',['../../Circular_kernel_3/classAlgebraicKernelForSpheres_1_1ZCriticalPoints.html',1,'AlgebraicKernelForSpheres']]]
];
