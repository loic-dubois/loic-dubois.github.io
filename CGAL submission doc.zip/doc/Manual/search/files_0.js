var searchData=
[
  ['barycentric_5fcoordinates_5f2_2eh_0',['Barycentric_coordinates_2.h',['../../Barycentric_coordinates_2/Barycentric__coordinates__2_8h.html',1,'']]]
];
