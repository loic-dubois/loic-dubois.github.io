var searchData=
[
  ['quadratic_5fprogram_5fpricing_5fstrategy_0',['Quadratic_program_pricing_strategy',['../../QP_solver/group__PkgQPSolverFunctions.html#ga5e4c5717fab328c4e94c3d58e1bd4517',1,'CGAL']]],
  ['quadratic_5fprogram_5fstatus_1',['Quadratic_program_status',['../../QP_solver/group__PkgQPSolverClasses.html#gad1152456fa1f4b03083fea7a83772d63',1,'CGAL']]],
  ['query_5fpoint_5flocation_2',['Query_point_location',['../../Barycentric_coordinates_2/namespaceCGAL_1_1Barycentric__coordinates.html#aedeeb072a2024053a016afd15e591331',1,'CGAL::Barycentric_coordinates']]]
];
