var searchData=
[
  ['kernel_0',['Kernel',['../../Kernel_23/namespaceKernel.html',1,'']]]
];
