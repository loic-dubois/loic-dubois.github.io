var searchData=
[
  ['umbilics_20on_20triangulated_20surface_20meshes_20reference_0',['Approximation of Ridges and Umbilics on Triangulated Surface Meshes Reference',['../../Ridges_3/group__PkgRidges3Ref.html',1,'']]],
  ['uniform_20region_20weight_1',['Uniform Region Weight',['../../Weights/group__PkgWeightsRefUniformRegionWeights.html',1,'']]],
  ['uniform_20weight_2',['Uniform Weight',['../../Weights/group__PkgWeightsRefUniformWeights.html',1,'']]],
  ['union_20find_20modifiers_20reference_3',['Profiling Tools, Hash Map, Union-find, Modifiers Reference',['../../Miscellany/group__MiscellanyRef.html',1,'']]],
  ['union_20functions_4',['Union Functions',['../../Boolean_set_operations_2/group__boolean__join.html',1,'']]],
  ['univariate_20algebraic_20kernel_5',['Univariate Algebraic Kernel',['../../Algebraic_kernel_d/group__PkgAlgebraicKernelDConceptsUni.html',1,'']]],
  ['utilities_6',['Utilities',['../../Number_types/group__nt__util.html',1,'Utilities'],['../../Spatial_sorting/group__PkgSpatialSortingUtils.html',1,'Utilities'],['../../STL_Extension/group__PkgSTLExtensionUtilities.html',1,'Utilities']]]
];
