var searchData=
[
  ['intersection_5fmode_0',['Intersection_mode',['../../Nef_3/classCGAL_1_1Nef__polyhedron__3.html#a096557e7a2baaece098dc0ce836b2143',1,'CGAL::Nef_polyhedron_3']]],
  ['io_5foption_1',['IO_option',['../../Surface_mesher/group__PkgSurfaceMesher3FunctionsIO.html#ga79944e81075ea1199fe75e255d7d3393',1,'CGAL::Surface_mesher::IO_option'],['../../Surface_mesher/group__PkgSurfaceMesher3FunctionsIO.html#ga79944e81075ea1199fe75e255d7d3393',1,'CGAL::Surface_mesher::IO_option']]],
  ['iterator_5ftype_2',['Iterator_type',['../../Periodic_2_triangulation_2/classCGAL_1_1Periodic__2__triangulation__2.html#a7262186403a9101fef5d7d0d753ad77d',1,'CGAL::Periodic_2_triangulation_2::Iterator_type'],['../../Periodic_3_triangulation_3/classCGAL_1_1Periodic__3__triangulation__3.html#af8610f3f4e13cb37acd75e484af2af49',1,'CGAL::Periodic_3_triangulation_3::Iterator_type']]]
];
