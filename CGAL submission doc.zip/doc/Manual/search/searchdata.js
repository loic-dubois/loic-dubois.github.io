var indexSectionsWithContent =
{
  0: "012367abcdefghijklmnopqrstuvwxyz~",
  1: "abcdefghijklmnopqrstuvwxyz",
  2: "abcfkrs",
  3: "bcdefgilmnopqrstuw",
  4: "abcdefghijklmnopqrstuvwxyz~",
  5: "abcdefghilmnopqrstuvz",
  6: "abcdefghiklmnopqrstuvwxyz",
  7: "abcdefghilmopqrstuvw",
  8: "gop",
  9: "23abcdefghiklmnopqrstuvwx",
  10: "06abcdefghiklmnoprstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "related",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Friends",
  9: "Modules",
  10: "Pages"
};

