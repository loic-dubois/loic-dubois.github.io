var searchData=
[
  ['z_5fcritical_5fpoints_0',['Z_critical_points',['../../Circular_kernel_3/classAlgebraicKernelForSpheres.html#a09378ec9542c6ed5d29170367bcd0226',1,'AlgebraicKernelForSpheres']]]
];
