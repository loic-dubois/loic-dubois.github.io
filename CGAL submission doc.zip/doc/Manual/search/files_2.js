var searchData=
[
  ['double_2eh_0',['double.h',['../../Number_types/double_8h.html',1,'']]]
];
