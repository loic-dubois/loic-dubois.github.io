var searchData=
[
  ['rational_5ftraits_2eh_0',['Rational_traits.h',['../../Number_types/Rational__traits_8h.html',1,'']]],
  ['region_5fgrowing_2eh_1',['Region_growing.h',['../../Shape_detection/Region__growing_8h.html',1,'']]],
  ['regularize_5fcontours_2eh_2',['regularize_contours.h',['../../Shape_regularization/regularize__contours_8h.html',1,'']]],
  ['regularize_5fplanes_2eh_3',['regularize_planes.h',['../../Shape_regularization/regularize__planes_8h.html',1,'']]],
  ['regularize_5fsegments_2eh_4',['regularize_segments.h',['../../Shape_regularization/regularize__segments_8h.html',1,'']]],
  ['root_5fof_5ftraits_2eh_5',['Root_of_traits.h',['../../Number_types/Root__of__traits_8h.html',1,'']]],
  ['rootof_5f2_2eh_6',['RootOf_2.h',['../../Number_types/RootOf__2_8h.html',1,'']]]
];
