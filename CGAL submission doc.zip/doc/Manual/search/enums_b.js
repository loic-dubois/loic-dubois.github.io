var searchData=
[
  ['orbifold_5ftype_0',['Orbifold_type',['../../Surface_mesh_parameterization/group__PkgSurfaceMeshParameterizationEnums.html#ga9bf015e651e33c9a5ac0be11d05eed19',1,'CGAL::Surface_mesh_parameterization']]],
  ['oriented_5fside_1',['Oriented_side',['../../Kernel_23/group__kernel__enums.html#ga5006dd2552d97fa577d81bd819c0f979',1,'CGAL']]]
];
