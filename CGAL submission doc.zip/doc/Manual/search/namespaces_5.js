var searchData=
[
  ['realembeddabletraits_5f_0',['RealEmbeddableTraits_',['../../Algebraic_foundations/namespaceRealEmbeddableTraits__.html',1,'']]]
];
