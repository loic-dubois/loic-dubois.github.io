var searchData=
[
  ['bibliography_0',['Bibliography',['../citelist.html',1,'']]],
  ['board_1',['Editorial Board',['../devman_submission.html',1,'dev_manual']]],
  ['boost_20parameters_20to_20cgal_20named_20function_20parameters_2',['Upgrading Code using Boost Parameters to CGAL Named Function Parameters',['../../STL_Extension/FromBoostNPtoCGALNP.html',1,'']]]
];
