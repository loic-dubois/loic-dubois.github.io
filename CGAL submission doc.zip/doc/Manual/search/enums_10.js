var searchData=
[
  ['topology_0',['Topology',['../../Box_intersection_d/group__PkgBoxIntersectionDEnums.html#gac1b7703e33d0fe5d9d484493189c9cd8',1,'CGAL::Box_intersection_d::Topology'],['../../Box_intersection_d/group__PkgBoxIntersectionDEnums.html#gac1b7703e33d0fe5d9d484493189c9cd8',1,'CGAL::Box_intersection_d::Topology']]],
  ['type_5fof_5falgorithm_1',['Type_of_algorithm',['../../Barycentric_coordinates_2/namespaceCGAL_1_1Barycentric__coordinates.html#a5e5682512438422f23d6080edc49c05b',1,'CGAL::Barycentric_coordinates']]]
];
