var searchData=
[
  ['70_20and_20later_0',['Version 1.70 and Later',['../configurationvariables.html#inst_boost_1_70_plus',1,'']]]
];
