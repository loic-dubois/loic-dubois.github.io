var searchData=
[
  ['reading_0',['Recommended Reading',['../devman_info.html',1,'dev_manual']]],
  ['recommended_20reading_1',['Recommended Reading',['../devman_info.html',1,'dev_manual']]],
  ['reconstruction_20from_20point_20clouds_2',['Surface Reconstruction from Point Clouds',['../tuto_reconstruction.html',1,'tutorials']]],
  ['reference_20counting_20and_20handle_20types_3',['Reference Counting and Handle Types',['../devman_reference_counting.html',1,'dev_manual']]],
  ['reference_20pages_4',['Classified Reference Pages',['../../Algebraic_foundations/AlgebraicFoundationsClassified.html',1,'']]],
  ['return_20types_5',['Polymorphic Return Types',['../devman_polyret.html',1,'dev_manual']]],
  ['robustness_20issues_6',['Robustness Issues',['../devman_robustness.html',1,'dev_manual']]],
  ['running_20a_20testsuite_20locally_7',['Running a Testsuite Locally',['../devman_testing.html',1,'dev_manual']]]
];
