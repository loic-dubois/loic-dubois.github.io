var searchData=
[
  ['barycentric_5fcoordinates_5ftype_0',['Barycentric_coordinates_type',['../../Surface_mesh_shortest_path/namespaceCGAL_1_1Surface__mesh__shortest__paths__3.html#a5a0848571076ddb998924ce9ca771dc3',1,'CGAL::Surface_mesh_shortest_paths_3']]],
  ['boolean_5foperation_5ftype_1',['Boolean_operation_type',['../../Polygon_mesh_processing/group__PMP__corefinement__grp.html#ga3be2ae4b7de3a1d9288f7febfc27eb9a',1,'CGAL::Polygon_mesh_processing::Corefinement']]],
  ['boundary_2',['Boundary',['../../Nef_2/classCGAL_1_1Nef__polyhedron__2.html#a8cb9d4db15905d56ae4be1d502aab8ff',1,'CGAL::Nef_polyhedron_2::Boundary'],['../../Nef_S2/classCGAL_1_1Nef__polyhedron__S2.html#a0efe7db1ce8df143782f5f5a713e0fa6',1,'CGAL::Nef_polyhedron_S2::Boundary'],['../../Nef_3/classCGAL_1_1Nef__polyhedron__3.html#a633628c79ae6839428de5704e69b1cf3',1,'CGAL::Nef_polyhedron_3::Boundary']]],
  ['bounded_5fside_3',['Bounded_side',['../../Kernel_23/group__kernel__enums.html#gaf6030e89dadcc1f45369b0cdc5d9e111',1,'CGAL']]],
  ['box_5fparameter_5fspace_5f2_4',['Box_parameter_space_2',['../../Kernel_23/group__kernel__enums.html#ga69d3e68aa488b8927506333b04400bdf',1,'CGAL']]]
];
