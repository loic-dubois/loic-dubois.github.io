var searchData=
[
  ['efficient_5fransac_2eh_0',['Efficient_RANSAC.h',['../../Shape_detection/Efficient__RANSAC_8h.html',1,'']]],
  ['exact_5finteger_2eh_1',['Exact_integer.h',['../../Number_types/Exact__integer_8h.html',1,'']]],
  ['exact_5frational_2eh_2',['Exact_rational.h',['../../Number_types/Exact__rational_8h.html',1,'']]]
];
