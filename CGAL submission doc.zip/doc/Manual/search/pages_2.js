var searchData=
[
  ['a_20cmake_20script_20for_20a_20program_20using_20cgal_0',['Creating a CMake Script for a Program Using CGAL',['../devman_create_cgal_CMakeLists.html',1,'dev_manual']]],
  ['a_20testsuite_20locally_1',['Running a Testsuite Locally',['../devman_testing.html',1,'dev_manual']]],
  ['acknowledging_20cgal_2',['Acknowledging CGAL',['../how_to_cite_cgal.html',1,'']]],
  ['and_20handle_20types_3',['Reference Counting and Handle Types',['../devman_reference_counting.html',1,'dev_manual']]],
  ['and_20handles_4',['Iterators, Circulators and Handles',['../devman_iterators_and_circulators.html',1,'dev_manual']]],
  ['and_20postconditions_20assertions_20and_20warnings_5',['Checks: Pre- and Postconditions, Assertions, and Warnings',['../devman_checks.html',1,'dev_manual']]],
  ['and_20third_20party_20dependencies_6',['Compilers and Third Party Dependencies',['../thirdparty.html',1,'general_intro']]],
  ['assertions_20and_20warnings_7',['Checks: Pre- and Postconditions, Assertions, and Warnings',['../devman_checks.html',1,'dev_manual']]]
];
