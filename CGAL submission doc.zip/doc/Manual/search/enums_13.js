var searchData=
[
  ['weight_5ftype_0',['Weight_type',['../../Surface_mesh_parameterization/group__PkgSurfaceMeshParameterizationEnums.html#ga992e12bb57ad83cbeb41ff2439669561',1,'CGAL::Surface_mesh_parameterization']]]
];
