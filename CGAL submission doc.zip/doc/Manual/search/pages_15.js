var searchData=
[
  ['variables_0',['Summary of CGAL&apos;s Configuration Variables',['../configurationvariables.html',1,'general_intro']]],
  ['visual_20c_1',['Using CGAL on Windows (with Visual C++)',['../windows.html',1,'general_intro']]]
];
