var searchData=
[
  ['0_20manual_0',['CGAL 6.0 - Manual',['../index.html',1,'']]]
];
