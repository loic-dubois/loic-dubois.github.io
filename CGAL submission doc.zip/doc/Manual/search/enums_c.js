var searchData=
[
  ['point_5ftype_0',['Point_type',['../../Nef_2/classExtendedKernelTraits__2.html#a2877caaf9a92e39e3d4d86b54d87e9cc',1,'ExtendedKernelTraits_2']]]
];
