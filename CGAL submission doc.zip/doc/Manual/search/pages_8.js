var searchData=
[
  ['general_20information_0',['General Information',['../preliminaries.html',1,'general_intro']]],
  ['geographic_20information_20system_1',['GIS (Geographic Information System)',['../tuto_gis.html',1,'tutorials']]],
  ['geometry_20kernels_2',['Geometry Kernels',['../devman_kernels.html',1,'dev_manual']]],
  ['getting_20started_20with_20cgal_3',['Getting Started with CGAL',['../general_intro.html',1,'index']]],
  ['gis_20geographic_20information_20system_4',['GIS (Geographic Information System)',['../tuto_gis.html',1,'tutorials']]]
];
