var searchData=
[
  ['y_5fcritical_5fpoints_0',['Y_critical_points',['../../Circular_kernel_2/classAlgebraicKernelForCircles.html#a3083bfb0711e2afaa8ab0efcaf5ad04e',1,'AlgebraicKernelForCircles::Y_critical_points'],['../../Circular_kernel_3/classAlgebraicKernelForSpheres.html#a37b2904f3a63de4f3883127667f5a98c',1,'AlgebraicKernelForSpheres::Y_critical_points']]]
];
