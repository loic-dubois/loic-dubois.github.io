var searchData=
[
  ['core_5fbigfloat_2eh_0',['CORE_BigFloat.h',['../../Number_types/CORE__BigFloat_8h.html',1,'']]],
  ['core_5fbigint_2eh_1',['CORE_BigInt.h',['../../Number_types/CORE__BigInt_8h.html',1,'']]],
  ['core_5fbigrat_2eh_2',['CORE_BigRat.h',['../../Number_types/CORE__BigRat_8h.html',1,'']]],
  ['core_5fexpr_2eh_3',['CORE_Expr.h',['../../Number_types/CORE__Expr_8h.html',1,'']]]
];
