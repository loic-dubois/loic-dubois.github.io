var searchData=
[
  ['s_20configuration_20variables_0',['Summary of CGAL&apos;s Configuration Variables',['../configurationvariables.html',1,'general_intro']]],
  ['script_20for_20a_20program_20using_20cgal_1',['Creating a CMake Script for a Program Using CGAL',['../devman_create_cgal_CMakeLists.html',1,'dev_manual']]],
  ['started_20with_20cgal_2',['Getting Started with CGAL',['../general_intro.html',1,'index']]],
  ['summary_20of_20cgal_20s_20configuration_20variables_3',['Summary of CGAL&apos;s Configuration Variables',['../configurationvariables.html',1,'general_intro']]],
  ['supported_20file_20formats_4',['Supported File Formats',['../../Stream_support/IOStreamSupportedFileFormats.html',1,'']]],
  ['surface_20reconstruction_20from_20point_20clouds_5',['Surface Reconstruction from Point Clouds',['../tuto_reconstruction.html',1,'tutorials']]],
  ['system_6',['GIS (Geographic Information System)',['../tuto_gis.html',1,'tutorials']]]
];
