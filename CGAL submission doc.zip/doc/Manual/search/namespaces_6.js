var searchData=
[
  ['srtraits_5f2_0',['SRTraits_2',['../../Snap_rounding_2/namespaceSRTraits__2.html',1,'']]],
  ['std_1',['std',['../namespacestd.html',1,'']]]
];
