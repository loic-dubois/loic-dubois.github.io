var searchData=
[
  ['ycriticalpoints_0',['YCriticalPoints',['../../Circular_kernel_2/classAlgebraicKernelForCircles_1_1YCriticalPoints.html',1,'AlgebraicKernelForCircles::YCriticalPoints'],['../../Circular_kernel_3/classAlgebraicKernelForSpheres_1_1YCriticalPoints.html',1,'AlgebraicKernelForSpheres::YCriticalPoints']]],
  ['ymonotonepartitionisvalidtraits_5f2_1',['YMonotonePartitionIsValidTraits_2',['../../Partition_2/classYMonotonePartitionIsValidTraits__2.html',1,'']]]
];
