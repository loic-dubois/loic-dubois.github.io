var searchData=
[
  ['named_20function_20parameters_0',['Upgrading Code using Boost Parameters to CGAL Named Function Parameters',['../../STL_Extension/FromBoostNPtoCGALNP.html',1,'']]],
  ['namespaces_1',['Namespaces',['../devman_namespaces.html',1,'dev_manual']]],
  ['notice_2',['Deprecation Notice',['../deprecated.html',1,'dev_manual']]]
];
