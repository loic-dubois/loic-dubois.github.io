var searchData=
[
  ['libraries_0',['Installing CGAL libraries',['../installation.html',1,'general_intro']]],
  ['license_1',['License',['../license.html',1,'general_intro']]],
  ['linux_20macos_2',['Using CGAL on Unix (Linux, macOS, ...)',['../usage.html',1,'general_intro']]],
  ['locally_3',['Running a Testsuite Locally',['../devman_testing.html',1,'dev_manual']]]
];
