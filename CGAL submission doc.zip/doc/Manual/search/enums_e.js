var searchData=
[
  ['ridge_5forder_0',['Ridge_order',['../../Ridges_3/group__PkgRidges3Enums.html#ga00a3b23ecc61f7b02492e79cf7cf1b91',1,'CGAL']]],
  ['ridge_5ftype_1',['Ridge_type',['../../Ridges_3/group__PkgRidges3Enums.html#ga52a2c136a49dc8f32e146aa8204cb65a',1,'CGAL']]]
];
