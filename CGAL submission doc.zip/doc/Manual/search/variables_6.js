var searchData=
[
  ['general_0',['GENERAL',['../../Alpha_shapes_2/classCGAL_1_1Alpha__shape__2.html#ae1c8fee3b311d5417dd9c58c8a2b97f5a98f773aea96e5662d660bbf59e2d2bcc',1,'CGAL::Alpha_shape_2::GENERAL'],['../../Alpha_shapes_3/classCGAL_1_1Alpha__shape__3.html#aa6941cdb345b82d9aad513f8b7b1a6efa4684ead732e31e7517685b9e59d3005c',1,'CGAL::Alpha_shape_3::GENERAL']]]
];
