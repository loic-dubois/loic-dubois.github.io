var searchData=
[
  ['umbilic_5ftype_0',['Umbilic_type',['../../Ridges_3/group__PkgRidges3Enums.html#ga4a6962972d77b9dcc9dfd82fdb5cf822',1,'CGAL']]]
];
