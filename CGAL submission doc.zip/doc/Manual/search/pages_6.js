var searchData=
[
  ['editorial_20board_0',['Editorial Board',['../devman_submission.html',1,'dev_manual']]]
];
