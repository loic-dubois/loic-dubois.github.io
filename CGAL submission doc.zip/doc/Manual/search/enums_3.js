var searchData=
[
  ['deformation_5falgorithm_5ftag_0',['Deformation_algorithm_tag',['../../Surface_mesh_deformation/group__PkgSurfaceMeshDeformationRef.html#gabccf12c64e4e13d82a0b5f5ca17d55f5',1,'CGAL']]],
  ['delaunay_5fvoronoi_5fkind_1',['Delaunay_voronoi_kind',['../../Convex_hull_d/classCGAL_1_1Delaunay__d.html#a5dda4e3061b66c31d4597d0eaf5c1666',1,'CGAL::Delaunay_d']]]
];
