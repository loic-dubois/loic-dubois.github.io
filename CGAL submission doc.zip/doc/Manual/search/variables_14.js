var searchData=
[
  ['zero_0',['ZERO',['../../Kernel_23/group__kernel__enums.html#gga59bee58a806ccde81562ea315ff75525a15dcf7100dd2016acdd8172e81a7cb09',1,'CGAL']]]
];
