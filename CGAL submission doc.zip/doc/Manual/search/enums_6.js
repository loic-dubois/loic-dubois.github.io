var searchData=
[
  ['generator_0',['Generator',['../../Periodic_4_hyperbolic_triangulation_2/classCGAL_1_1Hyperbolic__octagon__translation.html#ad8d7068cd336de2c5a59b841b6d32b3d',1,'CGAL::Hyperbolic_octagon_translation']]]
];
