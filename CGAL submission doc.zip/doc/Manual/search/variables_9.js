var searchData=
[
  ['larger_0',['LARGER',['../../Kernel_23/group__kernel__enums.html#gga84351c7e66be00efccd4ab1a61070469ab25bdbfd193e9ea35187a4f46e7d6fcd',1,'CGAL']]],
  ['left_5fboundary_1',['LEFT_BOUNDARY',['../../Kernel_23/group__kernel__enums.html#gga69d3e68aa488b8927506333b04400bdfaea36d4831df16606dc880b9adb4a593b',1,'CGAL']]],
  ['left_5fturn_2',['LEFT_TURN',['../../Kernel_23/group__kernel__enums.html#ga803e5969acd01d45aec5acaee6f82883',1,'CGAL']]],
  ['leftframe_3',['LEFTFRAME',['../../Nef_2/classExtendedKernelTraits__2.html#a2877caaf9a92e39e3d4d86b54d87e9cca571e8a45e7d6379a459286a21ee384d3',1,'ExtendedKernelTraits_2']]],
  ['less_5fdistance_5fto_5fpoint_5f3_4',['Less_distance_to_point_3',['../../Convex_hull_3/classCGAL_1_1Convex__hull__traits__3.html#a5ec640135eee2db9c27d1d123b562ad4',1,'CGAL::Convex_hull_traits_3']]],
  ['less_5fsigned_5fdistance_5fto_5fplane_5f3_5',['Less_signed_distance_to_plane_3',['../../Convex_hull_3/classCGAL_1_1Convex__hull__traits__3.html#a637c05778e42dc3529ab4cdfe45f7c33',1,'CGAL::Convex_hull_traits_3']]],
  ['lmwt_6',['LMWT',['../../Nef_2/classCGAL_1_1Nef__polyhedron__2.html#aa7cddcb2fffffe488f897da1f3cf4abca775e12588827baac52ff0b8d3dec1616',1,'CGAL::Nef_polyhedron_2']]]
];
