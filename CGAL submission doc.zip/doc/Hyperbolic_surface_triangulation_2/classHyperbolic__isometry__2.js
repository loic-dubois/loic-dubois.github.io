var classHyperbolic__isometry__2 =
[
    [ "ComplexNumber", "classHyperbolic__isometry__2.html#acea0cd83e85cbb4ab94511060fa98f0d", null ],
    [ "Point", "classHyperbolic__isometry__2.html#abe62515ed97c87c060896f350ff37559", null ],
    [ "Hyperbolic_isometry_2", "classHyperbolic__isometry__2.html#a530d7de5a477bb146a0cbb8197d52c0b", null ],
    [ "compose", "classHyperbolic__isometry__2.html#afeec18de0407c704f26c610b12cdcc96", null ],
    [ "evaluate", "classHyperbolic__isometry__2.html#a211fa96ae9769d65400cbf1ffa6384b4", null ],
    [ "get_coefficient", "classHyperbolic__isometry__2.html#a354b6afb2f69781bbdbe28b6992eafd9", null ],
    [ "operator<<", "classHyperbolic__isometry__2.html#aa7b9cf820d61b425cd597e8615aae49b", null ],
    [ "set_coefficient", "classHyperbolic__isometry__2.html#af04805a4ef10822560beee444541594d", null ],
    [ "set_coefficients", "classHyperbolic__isometry__2.html#a0fd5a9de62e13cd39eac4ef1083c0e33", null ],
    [ "set_to_identity", "classHyperbolic__isometry__2.html#a97d97df91e41c9b993574cb501b73ab7", null ]
];