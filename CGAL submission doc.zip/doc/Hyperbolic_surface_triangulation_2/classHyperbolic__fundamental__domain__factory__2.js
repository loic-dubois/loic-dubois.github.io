var classHyperbolic__fundamental__domain__factory__2 =
[
    [ "Hyperbolic_fundamental_domain_factory_2", "classHyperbolic__fundamental__domain__factory__2.html#adc2c9cecd5662c09f8b499b11dd52998", null ],
    [ "generate_domain_g2", "classHyperbolic__fundamental__domain__factory__2.html#ae65020bcd7ee181dec3c1c00b1bcd6a3", null ]
];