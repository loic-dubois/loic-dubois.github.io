var group__PkgHyperbolicSurfaceTriangulation2TraitsClasses =
[
    [ "CGAL::Hyperbolic_surfaces_traits_2< HyperbolicTraitsClass >", "classCGAL_1_1Hyperbolic__surfaces__traits__2.html", null ]
];