var index =
[
    [ "Hyperbolic surfaces", "index.html#Section_Hyperbolic_Surface_Triangulations_Background", [
      [ "Fundamental domains and triangulations", "index.html#Section_Hyperbolic_Surface_Triangulations_domains", null ],
      [ "Generation of convex fundamental domains", "index.html#Section_Hyperbolic_Surface_Triangulations_generation", null ]
    ] ],
    [ "Representation", "index.html#Subsection_Hyperbolic_Surface_Triangulations_Representation", [
      [ "Data structure for domains", "index.html#Subsection_Hyperbolic_Surface_Triangulations_DS_Domains", null ],
      [ "Data structure for triangulations", "index.html#Subsection_Hyperbolic_Surface_Triangulations_DS_Triangulations", null ],
      [ "Delaunay flip algorithm", "index.html#Subsection_Hyperbolic_Surface_Triangulations_Delaunay", null ]
    ] ],
    [ "Software design", "index.html#Section_Hyperbolic_Surface_Triangulations_Software_Design", null ],
    [ "Example", "index.html#Section_Hyperbolic_Surface_Triangulations_Example", null ],
    [ "Design and implementation history", "index.html#Section_Hyperbolic_Surface_Implementation_History", null ]
];