var classHyperbolicSurfacesTraits__2 =
[
    [ "Complex", "classHyperbolicSurfacesTraits__2.html#aaef3d209d434b8199661827a3f0db265", null ],
    [ "FT", "classHyperbolicSurfacesTraits__2.html#a3aa030464db08400c0d4c24b7d0d0ad1", null ],
    [ "Hyperbolic_point_2", "classHyperbolicSurfacesTraits__2.html#ab2718336e6e158cadf740a4ad0a58748", null ]
];