var group__PkgHyperbolicSurfaceTriangulation2Ref =
[
    [ "Concepts", "group__PkgHyperbolicSurfaceTriangulation2Concepts.html", "group__PkgHyperbolicSurfaceTriangulation2Concepts" ],
    [ "Main Classes", "group__PkgHyperbolicSurfaceTriangulation2MainClasses.html", "group__PkgHyperbolicSurfaceTriangulation2MainClasses" ],
    [ "Traits Classes", "group__PkgHyperbolicSurfaceTriangulation2TraitsClasses.html", "group__PkgHyperbolicSurfaceTriangulation2TraitsClasses" ]
];