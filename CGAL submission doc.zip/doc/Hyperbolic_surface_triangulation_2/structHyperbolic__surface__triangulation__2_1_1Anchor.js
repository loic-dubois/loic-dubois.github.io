var structHyperbolic__surface__triangulation__2_1_1Anchor =
[
    [ "dart", "structHyperbolic__surface__triangulation__2_1_1Anchor.html#adc6d257ada38dbdc2a3a1039de7111e6", null ],
    [ "vertices", "structHyperbolic__surface__triangulation__2_1_1Anchor.html#af9d0b4da168fa58983212a4c603c5ef1", null ]
];